﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Atdi.AppServer.Contracts.Sdrns;

namespace Atdi.AppServer.AppService.SdrnsControllerv2_0
{
    public static class MeasSubTaskStationExtend
    {
        public static bool ValidationMeas(this MeasSubTaskStation SubTaskStation)
        {
            return true;
        }
    }
}
